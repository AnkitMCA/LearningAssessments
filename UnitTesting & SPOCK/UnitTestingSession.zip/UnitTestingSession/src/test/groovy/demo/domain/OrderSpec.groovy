package demo.domain

import spock.lang.Specification

class OrderSpec extends Specification {

    def "Testing Order getQuantity()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Initialize order"
        order.setQuantity(2)

        and: "Quantity Response"
        int response

        when:
        response = order.getQuantity()

        then:
        response == 2
    }

    def "Testing Order setQuantity()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Quantity Parameter"
        int param = 150

        when:
        order = order.setQuantity(param)

        then:
        order.getQuantity() == param
    }

    def "Testing Order getPrice()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Initialize order"
        order.setPrice(500)

        and: "Price Response"
        double response

        when:
        response = order.getPrice()

        then:
        response == 500D
    }

    def "Testing Order setPrice()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Price param"
        double param = 243D

        when:
        order = order.setPrice(param)

        then:
        order.getPrice() == param
    }


    def "Testing Order getItemName()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Initialize order"
        order.setItemName("PRODUCT ONE")

        and: "Item Name Response"
        String response

        when:
        response = order.getItemName()

        then:
        response == "PRODUCT ONE"
    }


    def "Testing Order setItemName()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Item Name param"
        String response = "Updated Product"

        when:
        order = order.setItemName(response)

        then:
        order.getItemName() == response
    }


    def "Testing Order getPriceWithTax()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Initializing order"
        order.setPriceWithTex(2541.80)

        and: "Price with Tax Response"
        double response

        when:
        response = order.getPriceWithTex()

        then:
        response == 2541.80D
    }

    def "Testing Order setPriceWithTex()"() {

        given: "Creating Order instance"
        Order order = new Order()

        and: "Price with Tax Response"
        double response = 486.83

        when:
        order = order.setPriceWithTex(response)

        then:
        order.getPriceWithTex() == response
    }
}
